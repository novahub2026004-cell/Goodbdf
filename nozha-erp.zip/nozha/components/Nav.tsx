"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import Bell from "./Bell";

const TABS = [
  ["/", "نظرة عامة"], ["/branches", "الفروع"], ["/employees", "الموظفون"], ["/attendance", "الحضور والانصراف"],
  ["/daily", "الروتين اليومي"], ["/tasks", "المهام"], ["/quality", "الجودة"], ["/complaints", "البلاغات والصيانة"],
  ["/chat", "المحادثات"], ["/documents", "الأرشيف"], ["/reports", "التقارير"],
] as const;

export default function Nav({ title, subtitle, userId, role }: { title: string; subtitle: string; userId: string; role: string }) {
  const path = usePathname();
  const router = useRouter();
  const logout = async () => { await supabaseBrowser().auth.signOut(); router.replace("/login"); router.refresh(); };
  const tabs = role === "super_admin" || role === "area_manager" ? [...TABS, ["/log", "سجل الأنشطة"] as const] : TABS;
  return (
    <header className="bg-[#1a6fd8] text-white">
      <div className="flex items-start justify-between px-5 pt-4">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-bold">{title}</h1>
            <span className="rounded-full bg-white/20 px-3 py-0.5 text-xs">نسخة تجريبية</span>
          </div>
          <p className="mt-1 text-xs text-white/80">{subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          <Bell userId={userId} />
          <button onClick={logout} className="rounded-lg bg-white/15 px-4 py-1.5 text-sm hover:bg-white/25">تسجيل الخروج</button>
        </div>
      </div>
      <nav className="mt-3 flex gap-1 overflow-x-auto px-4 pb-3">
        {tabs.map(([href, label]) => {
          const active = href === "/" ? path === "/" : path.startsWith(href);
          return (
            <Link key={href} href={href}
              className={`whitespace-nowrap rounded-xl px-4 py-2 text-sm ${active ? "bg-white font-semibold text-[#1a6fd8]" : "text-white/90 hover:bg-white/15"}`}>
              {label}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}
