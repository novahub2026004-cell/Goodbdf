export const inp = "rounded-lg border border-gray-200 bg-gray-50 px-3 py-2 text-sm outline-none focus:border-[#1a6fd8]";
export const btn = "rounded-lg bg-[#1a6fd8] px-4 py-2 text-sm font-semibold text-white disabled:opacity-50";
export const card = "rounded-2xl bg-white p-4 shadow-sm";
export const hhmm = (ts?: string | null) =>
  ts ? new Date(ts).toLocaleTimeString("en-GB", { timeZone: "Africa/Cairo", hour: "2-digit", minute: "2-digit" }) : "";
export const today = () => new Date().toLocaleDateString("en-CA", { timeZone: "Africa/Cairo" });
