# Free hosting (Vercel Hobby + Supabase Free) - about 15 minutes

1. **Supabase**: supabase.com -> New project (free). SQL Editor -> run in order:
   `0001_init.sql`, `0002_username.sql`, `0003_task_status.sql` (alone), `0004_architecture_update.sql`, `0005_notify_attendance_employees.sql`, `0006_hours_attendance_rpc.sql`, `0007_soft_delete_checklists.sql`.
2. Settings -> API: copy *Project URL*, *anon key*, *service_role key*.
3. Local: `cp .env.example .env.local`, fill the 3 values, `npm install`, `npm run seed`, `npm run dev`.
4. **GitHub**: create a private repo and push the project folder.
5. **Vercel**: vercel.com -> Add New Project -> import the repo -> add env vars
   `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` (NOT the service role key) -> Deploy.
6. Open the `*.vercel.app` link on the phone -> browser menu -> "Add to Home Screen" (PWA install).
7. Supabase -> Authentication -> URL Configuration: set Site URL to the Vercel link.
Free-tier note: Supabase Free pauses after ~7 days of inactivity (one click to resume). Fine for the client review.
