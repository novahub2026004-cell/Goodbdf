import { supabaseServer } from "@/lib/supabase/server";

const count = (sb: any, table: string, f?: (q: any) => any) => {
  let q = sb.from(table).select("*", { count: "exact", head: true });
  if (f) q = f(q);
  return q.then((r: any) => r.count ?? 0);
};

export default async function Dashboard() {
  const sb = await supabaseServer();
  const today = new Date().toISOString().slice(0, 10);
  const [branches, employees, openTasks, closedTasks, openComplaints, openMaint, att, quality, log] = await Promise.all([
    count(sb, "branches"),
    count(sb, "employees"),
    count(sb, "tasks", (q) => q.not("status", "in", "(approved,closed)")),
    count(sb, "tasks", (q) => q.in("status", ["approved", "closed"])),
    count(sb, "complaints", (q) => q.in("status", ["open", "in_progress"])),
    count(sb, "maintenance_requests", (q) => q.in("status", ["open", "in_progress"])),
    sb.from("attendance").select("status").eq("work_date", today),
    sb.from("quality_submissions").select("percentage"),
    sb.from("activity_log").select("action, entity, created_at").order("created_at", { ascending: false }).limit(8),
  ]);
  const a = att.data ?? [];
  const attRate = employees ? Math.round((a.filter((x: any) => x.status === "present" || x.status === "late").length / employees) * 100) : 0;
  const q = quality.data ?? [];
  const qRate = q.length ? Math.round(q.reduce((s: number, x: any) => s + Number(x.percentage), 0) / q.length) : 0;

  const cards = [
    ["عدد الفروع", branches, "bg-[#1a6fd8]"], ["عدد الموظفين", employees, "bg-[#8b5cf6]"],
    ["نسبة الحضور اليوم", `${attRate}%`, "bg-[#3fb56a]"], ["نسبة الجودة", `${qRate}%`, "bg-[#2fa8c9]"],
    ["المهام المفتوحة", openTasks, "bg-[#e8801a]"], ["المهام المنتهية", closedTasks, "bg-[#3fb56a]"],
    ["البلاغات المفتوحة", openComplaints, "bg-[#e02b20]"], ["طلبات الصيانة", openMaint, "bg-[#6b7280]"],
  ];
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map(([label, val, color]) => (
          <div key={label as string} className={`${color} rounded-2xl p-5 text-white shadow`}>
            <div className="text-sm opacity-90">{label}</div>
            <div className="mt-2 text-4xl font-bold">{val}</div>
          </div>
        ))}
      </div>
      <section className="rounded-2xl bg-white p-5 shadow-sm">
        <h2 className="mb-3 font-bold">آخر الأنشطة</h2>
        {(log.data ?? []).length === 0 ? <p className="text-sm text-gray-400">لا توجد أنشطة بعد</p> : (
          <ul className="divide-y text-sm">
            {log.data!.map((l: any, i: number) => (
              <li key={i} className="flex justify-between py-2"><span>{l.action} - {l.entity}</span>
                <span className="text-gray-400">{new Date(l.created_at).toLocaleString("ar-EG")}</span></li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
