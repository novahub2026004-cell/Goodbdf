"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { btn, card, inp } from "@/components/ui";

export default function Manager({ branches, managers, admin }: any) {
  const sb = supabaseBrowser(), router = useRouter();
  const [f, setF] = useState({ code: "", name: "", city: "" });
  const [err, setErr] = useState("");
  const run = async (fn: () => PromiseLike<{ error: any }>) => { const { error } = await fn(); setErr(error?.message ?? ""); router.refresh(); };
  const upd = (id: string, patch: object) => run(() => sb.from("branches").update(patch).eq("id", id));
  const mgrOf = (b: string) => managers.find((m: any) => m.branch_id === b)?.id ?? "";
  return (
    <div className="space-y-4">
      {err && <p className="text-sm text-red-600">{err}</p>}
      {admin && <div className={card}><h2 className="mb-3 font-bold">إضافة فرع</h2><div className="flex flex-wrap gap-2">
        <input className={inp} placeholder="الكود (NZ-10)" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} />
        <input className={inp} placeholder="اسم الفرع" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <input className={inp} placeholder="المدينة" value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })} />
        <button className={btn} onClick={async () => { if (f.code && f.name) { await run(() => sb.from("branches").insert({ code: f.code, name: f.name, city: f.city })); setF({ code: "", name: "", city: "" }); } }}>إضافة</button></div></div>}
      <div className={`${card} overflow-x-auto`}>
        <table className="w-full text-sm">
          <thead><tr className="text-gray-400">{["الكود", "الفرع", "24 ساعة", "الفتح", "الإغلاق", "سماحية (د)", "المدير المسؤول", ""].map((h) => <th key={h} className="p-2 text-right font-semibold">{h}</th>)}</tr></thead>
          <tbody>{branches.map((b: any) => (
            <tr key={b.id} className="border-t">
              <td className="p-2">{b.code}</td>
              <td className="p-2"><input className={`${inp} w-40`} disabled={!admin} defaultValue={b.name} onBlur={(e) => e.target.value !== b.name && upd(b.id, { name: e.target.value })} /></td>
              <td className="p-2"><input type="checkbox" disabled={!admin} checked={b.is_24h} onChange={(e) => upd(b.id, { is_24h: e.target.checked })} /></td>
              <td className="p-2"><input type="time" className={`${inp} w-28`} disabled={!admin || b.is_24h} defaultValue={b.opens_at.slice(0, 5)} onBlur={(e) => e.target.value && upd(b.id, { opens_at: e.target.value })} /></td>
              <td className="p-2"><input type="time" className={`${inp} w-28`} disabled={!admin || b.is_24h} defaultValue={b.closes_at.slice(0, 5)} onBlur={(e) => e.target.value && upd(b.id, { closes_at: e.target.value })} /></td>
              <td className="p-2"><input type="number" className={`${inp} w-20`} disabled={!admin} defaultValue={b.grace_minutes} onBlur={(e) => +e.target.value !== b.grace_minutes && upd(b.id, { grace_minutes: +e.target.value })} /></td>
              <td className="p-2"><select className={inp} disabled={!admin} value={mgrOf(b.id)} onChange={(e) => e.target.value && run(() => sb.rpc("assign_branch_manager", { b: b.id, u: e.target.value }))}>
                <option value="">— بدون مدير —</option>{managers.map((m: any) => <option key={m.id} value={m.id}>{m.full_name}</option>)}</select></td>
              <td className="p-2">{admin && <button className="text-red-600" onClick={() => confirm("حذف الفرع؟ (يبقى السجل محفوظًا)") && run(() => sb.rpc("delete_branch", { b: b.id }))}>حذف</button>}</td>
            </tr>))}</tbody>
        </table>
        <p className="mt-2 text-xs text-gray-400">في الفروع 24 ساعة تُحدَّد وردية كل موظف من شاشة الحضور. أي تعديل في الساعات يصل لمدير الفرع فورًا.</p>
      </div>
    </div>
  );
}
