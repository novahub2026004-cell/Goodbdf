import { ctx } from "@/lib/session";
import { today } from "@/components/ui";
import Daily from "./client";

export default async function Page({ searchParams }: { searchParams: Promise<Record<string, string>> }) {
  const sp = await searchParams;
  const { sb, admin, profile, user } = await ctx();
  const { data: tpls } = await sb.from("checklist_templates").select("id,name,checklist_items(id,section,label,sort_order,is_active)").eq("is_active", true).order("created_at");
  const branches = admin ? (await sb.from("branches").select("id,name").order("code")).data ?? [] : [];
  const branchId = admin ? sp.branch || branches[0]?.id : profile.branch_id;
  const date = sp.date || today();
  const tplId = sp.tpl || tpls?.[0]?.id;
  const { data: report } = tplId && branchId
    ? await sb.from("daily_reports").select("id,notes,submitted_at,profiles(full_name),daily_report_items(item_id,is_done)")
        .eq("branch_id", branchId).eq("template_id", tplId).eq("report_date", date).maybeSingle()
    : { data: null };
  return <Daily key={`${tplId}${branchId}${date}${report?.id}`} tpls={tpls ?? []} tplId={tplId} branches={branches} branchId={branchId}
    date={date} report={report} admin={admin} userId={user.id} isToday={date === today()} />;
}
