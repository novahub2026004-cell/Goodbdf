"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { supabaseBrowser } from "@/lib/supabase/client";
import { toEmail, toPassword } from "@/lib/auth";

export default function Login() {
  const router = useRouter();
  const [u, setU] = useState(""); const [p, setP] = useState("");
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setErr("");
    const { error } = await supabaseBrowser().auth.signInWithPassword({ email: toEmail(u), password: toPassword(p) });
    setBusy(false);
    if (error) return setErr("اسم المستخدم أو كلمة المرور غير صحيحة");
    router.replace("/"); router.refresh();
  };
  const input = "w-full rounded-xl border border-gray-200 bg-gray-50 px-4 py-3 text-sm outline-none focus:border-[#1a6fd8]";
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-2xl bg-white p-8 shadow">
        <div className="text-center">
          <h1 className="text-xl font-bold">نظام إدارة فروع نزهة</h1>
          <p className="mt-1 text-sm text-gray-400">تسجيل الدخول</p>
        </div>
        <input className={input} placeholder="اسم المستخدم" value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" />
        <input className={input} type="password" placeholder="كلمة المرور" value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" />
        {err && <p className="text-sm text-red-600">{err}</p>}
        <button disabled={busy} className="w-full rounded-xl bg-[#1a6fd8] py-3 font-semibold text-white disabled:opacity-60">
          {busy ? "جارٍ الدخول..." : "دخول"}
        </button>
        <div className="rounded-xl bg-gray-100 p-3 text-xs text-gray-600">
          <p className="mb-1 font-semibold text-[#1a6fd8]">حسابات النسخة التجريبية</p>
          <p>المدير العام: 1234 / 1234</p>
          <p>مديرو الفروع: manager1 ... manager9 / 1234</p>
        </div>
      </form>
    </div>
  );
}
