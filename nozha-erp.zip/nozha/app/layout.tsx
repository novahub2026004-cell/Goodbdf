import type { Metadata, Viewport } from "next";
import { Cairo } from "next/font/google";
import "./globals.css";
import PwaRegister from "@/components/PwaRegister";

const cairo = Cairo({ subsets: ["arabic", "latin"], variable: "--font-cairo" });

export const metadata: Metadata = {
  title: "نظام إدارة فروع نزهة",
  manifest: "/manifest.json",
  appleWebApp: { capable: true, title: "نزهة" },
};
export const viewport: Viewport = { themeColor: "#1a6fd8" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${cairo.variable} font-cairo min-h-screen`}>
        {children}
        <PwaRegister />
      </body>
    </html>
  );
}
