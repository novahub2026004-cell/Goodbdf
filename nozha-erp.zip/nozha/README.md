# Nozha Branch Operations ERP - Module 0 + 1 (Foundation + Auth + Dashboard)

## Setup
1. Create a Supabase project. In SQL editor run, in order: `supabase/migrations/0001_init.sql`, then `0002_username.sql`.
2. `cp .env.example .env.local` and fill the 3 values (Project Settings -> API).
3. `npm install && npm run seed` (run once on an empty project).
4. `npm run dev`  ->  login `1234 / 1234` or `manager1 / 1234`.
5. Deploy: import the repo in Vercel, add the same env vars (skip the service role key there).

## Roles in demo
- `1234` = Super Admin (sees everything). `manager1..9` = Branch Manager (own branch only, enforced by RLS).

## Next modules
Branches/Employees CRUD -> Attendance -> Tasks (realtime) -> Notifications -> Daily/Quality -> Complaints -> Chat -> Documents -> Reports -> Activity log -> PWA polish.
